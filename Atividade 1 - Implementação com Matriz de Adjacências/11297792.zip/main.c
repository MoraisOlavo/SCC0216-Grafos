//Olavo Morais Borges Pereira 11297792
#include "GrafoMatriz.h"
#include <stdio.h>
//Le os valores iniciais e cria o grafo
void IniciarGrafo(GrafoMatriz* g){//Endereco do grafo
	int aux,u,v;
	scanf("%d",&aux);//Le o numero de vertices o grafo deve possuir
	CriarGrafo(g,aux);//Cria o grafo

	scanf("%d",&aux);//Le quantas arestas serao criadas
	for(int i=0;i<aux;i++){
		scanf("%d %d",&u,&v);//Le os vertices da aresta a ser criada
		InserirAresta(g,u,v);//Insere a aresta no grafo
	}

}

void GerenciarOperacoes(GrafoMatriz* g){//Endereco do grafo
	int q,op,u,v;
	scanf("%d",&q);//Le a quantidade de operacoes a serem feitas
	for(int i=0;i<q;i++){
		scanf("%d",&op);//Le qual operacao deve ser feita
		switch(op){
			case 1:
				scanf("%d %d",&u,&v);//Le quais os vertices da nova aresta
				InserirAresta(g,u,v);//Insere a aresta
				break;
			case 2:
				scanf("%d %d",&u,&v);//Le quais os vertices da aresta a ser removida
				RemoverAresta(g,u,v);//Remove a aresta
				break;
			default:
				ExibirGrafo(g);//Exibe o grafo
		}
	}
}

int main(){
	GrafoMatriz g;//Reserva espaco para um grafo
	IniciarGrafo(&g);//Inicia o programa
	GerenciarOperacoes(&g);//Executa as operacoes desejadas
	DeletarGrafo(&g);//Deleta o grafo
	return 0;
}
