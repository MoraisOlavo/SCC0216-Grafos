//Olavo Morais Borges Pereira 11297792
#ifndef GrafoMatriz_h
#define GrafoMatriz_h
typedef struct{
	int nVertices;//Armazena o numero de vertices
	int** vertices;//Ponteiro para a matriz
}GrafoMatriz;

int CriarGrafo(GrafoMatriz* g,int n);//Cria o grafo com espaco para n vertices
int InserirAresta(GrafoMatriz* g,int u,int v);//Insere aresta entre os vertices u,v
int RemoverAresta(GrafoMatriz* g,int u,int v);//Remove aresta entre os vertices u,v
void ExibirGrafo(GrafoMatriz* g);//Exibe na tela o grafo
int DeletarGrafo(GrafoMatriz* g);//Libera o espaco alocado pelo grafo
#endif
