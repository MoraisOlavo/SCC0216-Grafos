//Olavo Morais Borges Pereira 11297792
#include "GrafoLista.h"
#include <stdio.h>
//Percorre o grafo calculando a altura de cada vértice
void DFS(GrafoLista* g,int v,int* altura,int* ciclo){//Endereço do grafo,vértice a ser calculado a altura,vetor com as alturas e endereço da variável que armazena se encontrou algum ciclo

	int maiorAltura=0;//altura do maior vizinho do vértice atual
	altura[v]=0;//"pinta" o vértice atual de cinza, altura do vértice atual fica 0
	No* aux=(g->vetorListas+v)->ini;//Usado para percorrer a lista de adjacência
	
	while(aux!=NULL){//Enquanto houver elementos na lista de adjacência
		if(altura[aux->info]==0){//Se vizinho está com altura 0, está cinza
			*ciclo=1;//Encontrou um ciclo
			break;//Sai do while
		}
		if(altura[aux->info]==-1){//Se vizinho não tem altura calculada
			DFS(g,aux->info,altura,ciclo);//Calcula altura do vizinho
		}
		if(altura[aux->info]>maiorAltura){//Se altura do vizinho é maior que a maior altura já encontrada
			maiorAltura=altura[aux->info];//Altura do viznho passa a ser a maior altura já encontrada
		}
		aux=aux->prox;//Atualiza o vizinho
	}
	altura[v]=1+maiorAltura;//Define a altura do nó como altura do maior vizinho + 1

}

int main(){
	int aux,a,b;//variáveis usadas para criar o grafo
	scanf("%d",&aux);//Lê o número de vértices
	GrafoLista g;
	CriarGrafo(&g,aux);//Cria o grafo

	int altura[aux];//Cria o vetor com a altura de cada vértice
	for(int i=0;i<aux;i++){//Inicia o vetor com -1 em todas as posições
		altura[i]=-1;//Todos os vértices começam sem altura definida
	}

	scanf("%d",&aux);//Lê o número de relações de dependência
	for(int i=0;i<aux;i++){//Lê as dependências
		scanf("%d %d",&a,&b);//Lê os vértices da dependência
		InserirAresta(&g,a,b);//Cria um aresta dirigida de a até b
	}

	int maiorAltura=altura[0];//Variável para armazenar a maior altura já calculada, inicia com o valor da primeira altura
	int ciclo=0;//Variável usada para armazenar se há ou não um ciclo no grafo de dependências
	for(int i=0;i<g.nVertices;i++){//Percorre os vértices do grafo
		if(altura[i]==-1){//Se a altura do i-ésimo vértice não foi calculada ainda
			DFS(&g,i,altura,&ciclo);//Calcula a altura do i-ésimo vértice
		}
		if(altura[i]>maiorAltura){//Se a altura do i-ésimo vértice for maior que a maior altura até então
			maiorAltura=altura[i];//a altura do i-ésimo vértice se torna a nova maior altura
		}
	}
	
	if(ciclo==1){//Se encontrou um ciclo
		printf("-1\n");//Exibe -1
	}else{//Se não encontrou um ciclo
		printf("%d\n",maiorAltura);//Exibe a maior altura do grafo
	}
	DeletarGrafo(&g);//Libera a memória alocada pelo grafo lista

	return 0;
}
