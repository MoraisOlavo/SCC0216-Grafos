//Olavo Morais Borges Pereira
#include <stdio.h>
#include <stdlib.h>
#include "GrafoLista.h"

int CriarGrafo(GrafoLista* g,int n){//Endereco do grafo a ser criado e numero de vertices do grafo
	if(n<=0){//Se numero de vertices for invalido
		return 0;//Erro
	}
	g->nVertices=n;
	g->vetorListas=(ListaMedia*)malloc(n*sizeof(ListaMedia));//Reserva espaco para vetor de Listas
	for(int i=0;i<n;i++){//Inicia as listas
		CriarListaMedia(g->vetorListas+i);
	}
	return 1;//Sucesso
}

int InserirAresta(GrafoLista* g,int u,int v,int valorAresta){//Endereco do grafo e vertices da aresta a ser criada
	if(g->nVertices<=0 || u>=g->nVertices || v>=g->nVertices){//Se algum parametro for invalido
		return 0;//Erro
	}
	
	if(EstaNaListaMedia(g->vetorListas+u,v)==NULL){//Se nao existe aresta entre u,v
		InserirFinalListaMedia(g->vetorListas+u,v,valorAresta);//Insere v na lista u
	}
	return 1;//Sucesso
}

int RemoverAresta(GrafoLista* g,int u,int v){//Endereo do grafo e vertices da aresta a ser removida
        if(g->nVertices<=0 || u>=g->nVertices || v>=g->nVertices){//Se algum parametro for invalido
                return 0;//Erro
        }
        //Apaga a aresta(mesmo se ela nao existir)
	RemoverValorListaMedia(g->vetorListas+u,v);//Remove v da lista u(se v estiver na lista u)
	return 1;//Sucesso
}

//Obtém valor da aresta, retorna 1 se a aresta existe, 0 caso contráio
int ObterValorAresta(GrafoLista* g,int u,int v,int* valorAresta){
	No** aux=EstaNaListaMedia(g->vetorListas+u,v);
	if(aux==NULL){
		return 0;
	}
	*valorAresta=(*aux)->valorAresta;	
}

void ExibirGrafo(GrafoLista* g){//Endereco do grafo a ser exibido
	for(int i=0;i<g->nVertices;i++){//Cada volta representa a i-esima lista de arestas
		printf("%d: ",i);
		MostrarListaMedia(g->vetorListas+i);				
	}
	printf("\n");
}

int DeletarGrafo(GrafoLista* g){//Endereco do grafo a ser removido
	if(g->nVertices<=0){//Se o grafo for invalido
		return 0;//Erro
	}

	for(int i=0;i<g->nVertices;i++){//Libera o cada lista de adjacencias
		DestruirListaMedia(g->vetorListas+i);
	}
	free(g->vetorListas);//Remove o vetor com endereco de cada lista de arestas
	g->nVertices=0;//Define o numero de vertices como 0
	return 1;//Sucesso
}
