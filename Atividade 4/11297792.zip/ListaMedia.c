#include <stdio.h>
#include <stdlib.h>
#include "ListaMedia.h"

void CriarListaMedia(ListaMedia* l){//Endereço da lista que será iniciada
	//Inicializa as variaveis da lista
	l->ini=NULL;
	l->fim=NULL;
	l->numDeNos=0;
}

//Cria um nó com o valor passado
No* CriarNo(elem info,int valorAresta){//Valores que serão armazenado no nó
	No* p=(No*)malloc(sizeof(No));
	p->info=info;
	p->valorAresta=valorAresta;
	p->prox=NULL;
	return p;
}

int NumeroDeElementosListaMedia(ListaMedia* l){//Endereço da lista
	return l->numDeNos;
}

//Função interna que retorna o endereço de quem tem o endereço do nó procurado
No** ObterEnderecoListaMedia(ListaMedia* l,int pos){//Endereço da lista e posição desejada
	No** aux=&(l->ini);//aux é o endereço do primeiro ponteiro
	for(int i=0;i<pos && *aux!=NULL;i++){//Repetido pos vezes ou até aux conter o endereço de um ponteiro nulo
		aux=&((*aux)->prox);
	}
	return aux;
}

No* InserirInicioListaMedia(ListaMedia* l,elem valor,int valorAresta){//Endereço da lista e valor a ser inserido
	No* p=CriarNo(valor,valorAresta);
	p->prox=l->ini;//Faz p apontar para o primeiro
	l->ini=p;//Faz p ser o nó inicial
	if(l->fim==NULL){//Se não tiver último então p se torna
		l->fim=p;
	}
	l->numDeNos++;
	return p;
}

No* InserirFinalListaMedia(ListaMedia* l,elem valor,int valorAresta){//Endereço da lista e valor a ser inserido
	No* p=CriarNo(valor,valorAresta);
	if(l->fim!=NULL){//Tem alguem no final?
		l->fim->prox=p;//Se sim esse alguem aponta para p
	}else{//Senão o iniciao aponta para p
		l->ini=p;
	}
	l->fim=p;//o final aponta para p
	l->numDeNos++;
	return p;
}

No* InserirListaMedia(ListaMedia* l,elem valor,int pos,int valorAresta){//Endereço da lista,valor a ser inserido e posição desejada
	No* p=CriarNo(valor,valorAresta);
	No** aux=ObterEnderecoListaMedia(l,pos);//aux é o endereço de quem vai apontar para p

	if(*aux==NULL){//Se quem vai apontar para p era o ultimo
		l->fim=p;//então p é o ultimo agora
	}

	p->prox=*aux;//p aponta para quem *aux estava apontando
	*aux=p;//*aux aponta para p
	l->numDeNos++;
	return p;
}

void MostrarListaMedia(ListaMedia* l){//Endereço da lista que será exibida
	No* aux=l->ini;//aux é o nó que será mostrado
	while(aux!=NULL){
		printf("%d ",aux->info);
		aux=aux->prox;
	}
	printf("\n");
}

No** EstaNaListaMedia(ListaMedia* l,elem valor){//Endereço da Lista e valor procurado
	No** aux=&(l->ini);//Endereço de quem tem o endereço do nó procurado
	while(*aux!=NULL){
		if((*aux)->info==valor){//Verifica se o sucessor de aux é o procurado
			return aux;
		}
		aux=&((*aux)->prox);//Atualiza aux
	}
	return NULL;//Não encontrou
}

//Função interna que remove quem está na frente de p
void RemoverEnderecoListaMedia(ListaMedia* l,No** p,elem* retorno){//Endereço da lista,endereço de quem tem o endereço de quem será removido e endereço em que valor removido será armazenado
	No* noRemovido=*p;//Endereço que será removido
	*retorno=noRemovido->info;//Armazena o valor do nó removido
	*p=noRemovido->prox;//Atuliza o próximo de p
	l->numDeNos--;
	free(noRemovido);
}

int RemoverInicioListaMedia(ListaMedia* l,elem* retorno){//Endereço da lista e endereço que o valor removido será armazenado
	if(l->ini==NULL){//Se a lista estiver vazia
		return 0;
	}

	RemoverEnderecoListaMedia(l,&(l->ini),retorno);
	if(l->numDeNos==0){//Se o no removido era o unico da lista
		l->fim=NULL;//então não há mais último
	}
	return 1;
}

int RemoverFinalListaMedia(ListaMedia* l,elem* retorno){//Endereço da lista e endereço que o valor removido será armazenado
	if(l->ini==NULL){//Se a lista estiver vazia
		return 0;
	}

	if(NumeroDeElementosListaMedia(l)==1){//Se só tiver um elemento na lista
		RemoverInicioListaMedia(l,retorno);//Remove o único elemento da lista
		return 1;
	}

	No** aux=ObterEnderecoListaMedia(l,NumeroDeElementosListaMedia(l)-2);//aux é o endereço de quem tem o endereço do penúltimo nó
	RemoverEnderecoListaMedia(l,&((*aux)->prox),retorno);//Remove quem está na frente de aux
	l->fim=*aux;
	return 1;
}

int RemoverValorListaMedia(ListaMedia* l,elem valor){//Endereço da lista e valor do nó a ser removido
	if(l->ini==NULL){//Se a lista estiver vazia
		return 0;
	}

	elem* lixo=(elem*)malloc(sizeof(elem));//Usado na função RemoverEndereço
	
	if(l->ini->info==valor){//Se for para remover o primeiro elemento
		RemoverInicioListaMedia(l,lixo);//Remove o início
		free(lixo);//Libera o lixo
		return 1;
	}

	No* aux=l->ini;//Antecessor do nó que deve ser removido
	while(aux->prox!=NULL){//Encontra o antecessor do nó que deve ser removido
		if(aux->prox->info==valor){
			RemoverEnderecoListaMedia(l,&(aux->prox),lixo);//Remove o sucessor de aux
			free(lixo);//Libera o lixo
			return 1;
		}
		aux=aux->prox;
	}
	free(lixo);//libera o lixo
	return 0;//Não encontrou o elemendo a ser removido
}

int RemoverPosicaoListaMedia(ListaMedia* l,int pos,elem* retorno){//Endereço da lista e posição que deve ser removida
	if(l->ini==NULL){//Se lista estiver vazia
		return 0;
	}
	
	if(NumeroDeElementosListaMedia(l)==1 || pos>=NumeroDeElementosListaMedia(l)-1){//Se for para remover o último
		return RemoverFinalListaMedia(l,retorno);
	}

	No** aux=ObterEnderecoListaMedia(l,pos);//aux é o endereço de quem tem o endereço do nó a ser removido
	RemoverEnderecoListaMedia(l,aux,retorno);//Remove o nó desejado
	return 1;
}

int EstaVaziaListaMedia(ListaMedia* l){//Endereço da lista que será verificada
	if(l->ini==NULL){//Se não houver um nó inicial
		return 1;
	}else{//Se houver um nó inicial
		return 0;
	}
}

void DestruirListaMedia(ListaMedia* l){//Endereço da lista a ser destruída
	No* aux;//Endereço do nó a ser removido
	while(l->ini!=NULL){
		aux=l->ini;
		l->ini=l->ini->prox;
		free(aux);
	}
	l->fim=NULL;
	l->numDeNos=0;
}

