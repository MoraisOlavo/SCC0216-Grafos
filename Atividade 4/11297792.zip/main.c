//Olavo Morais Borges Pereira 11297792
#include <stdio.h>
#include "GrafoLista.h"

int VerificaMenor(int x,int y){
	if(x==-1){
		return 0;
	}
	if(y==-1){
		return 1;
	}
	if(x<y){
		return 1;
	}else{
		return 0;
	}
}

//Troca a posição de duas variáveis, usada para rearranjar a heap
void TrocarPosicao(int* x,int*y){//Endereço das variáveis
	int aux=*x;
	*x=*y;
	*y=aux;
}

//Rearranja a Heap
void RearranjarHeap(int *v,int* distancia,int raiz,int limite){//Endereço base do vetor,endereço base do vetor distancia, posicao onde inicia a heap e limite da heap
	int menor=raiz;//posicao do menor elemento, começa valendo a raiz da heap
	int filhoEsq=2*raiz+1,filhoDir=2*raiz+2;//posicoes do filho esquerdo e direito
	if(filhoEsq<limite && VerificaMenor(distancia[v[filhoEsq]],distancia[v[menor]])){//Se raiz tem filho esquerdo e ele é menor que a raiz
		menor=filhoEsq;//Posição do menor elemento passa a ser a do filho esquerdo
	}
	if(filhoDir<limite && VerificaMenor(distancia[v[filhoDir]],distancia[v[menor]])){//Se o raiz tem filho direito e ele é menor que o menor até então
		menor=filhoDir;//Posição do menor elemento passa a ser a do filho direito
	}
	if(menor!=raiz){//Se o raiz não é o menor
		//Faz a troca do raiz com o menor
		TrocarPosicao(v+raiz,v+menor);
		RearranjarHeap(v,distancia,menor,limite);//Chama a função recursivamente para garantir que a heap continue
	}
}

//Recebe o vetor e constrói uma heap
void ConstruirHeap(int*v,int* distancia,int n){//Vetor da heap, vetor da distancia e tamanho do vetor heap
	for(int i=(n/2)-1;i>=0;i--){//Rearranja a heap da metade do vetor até o início
		RearranjarHeap(v,distancia,i,n);
	}
}

//Obtém raiz da heap, retorna 0 se a heap está vazia
int ObterMenorHeap(int* heap,int limiteHeap,int* menorElemento){//Vetor heap,tamanho da heap, endereço para armazenar a raiz da heap
	if(limiteHeap<=0){//Se heap está vazia
		return 0;
	}
	//Se heap não está vazia
	*menorElemento=heap[0];//variável menorElemento recebe a raiz da heap
	return 1;
}

void MostrarVetor(int* v,int n){
	for(int i=0;i<n;i++){
		printf("%d ",v[i]);
	}
	printf("\n");
}

//Executa o algoritmo de dijkstra no vetor 
void dijkstra(GrafoLista g,int u,int* caminho){//Grafo a ser percorrido, vértice de origem e endereço base do vetor para armazenar o caminho
	int distancia[g.nVertices];//Cria o vetor que armazena a distancia dos nós ao nó origem
	int heap[g.nVertices];//Vetor da heap
	int limiteHeap=g.nVertices;

	//Inicia o vetor de caminhos
	for(int i=0;i<g.nVertices;i++){
		caminho[i]=-1;
		heap[i]=i;
		distancia[i]=-1;
	}

	distancia[u]=0;//Distancia do nó de origem até ele mesmo é 0

	ConstruirHeap(heap,distancia,limiteHeap);//Constrói a fila de prioridade

	int verticeAtual;
	while(ObterMenorHeap(heap,limiteHeap,&verticeAtual)){//Obtém o primeiro elemento da heap, sai do while quando a fila de prioridade estiver vazia
		TrocarPosicao(heap,heap+(limiteHeap-1));//Troca o raiz da heap com o seu último elemento
		limiteHeap--;//Decrementa o tamanho da heap
		for(No* aux=(g.vetorListas+verticeAtual)->ini;aux!=NULL;aux=aux->prox){//Percorre lista de adjacência do nó atual
			if(distancia[verticeAtual]!=-1 && VerificaMenor(distancia[verticeAtual]+aux->valorAresta,distancia[aux->info])){//Se a distância do vizinho do vértice atual for maior que a distância do vértice atual mais o peso da aresta
				distancia[aux->info]=distancia[verticeAtual]+aux->valorAresta;//Distância do vizinho recebe distância do vértice atual mais peso da aresta
				caminho[aux->info]=verticeAtual;//Armazena que para chegar ao vizinho se passa pelo nó atual
			}
		}
		//RearranjarHeap(heap,distancia,0,limiteHeap);
		ConstruirHeap(heap,distancia,limiteHeap);//Rearraja a Heap
	}
}

int main(){
	int n;
	scanf("%d",&n);//Armazena o tamanho do grafo
	GrafoLista gTempo,gPreco;//Grafo para armazenar o tempo e o preço das viagens
	CriarGrafo(&gTempo,n);//Inicia grafos
	CriarGrafo(&gPreco,n);
	
	scanf("%d",&n);//Armazena o número de arestas a serem inseridas
	int a,b,valor;
	for(int i=0;i<n;i++){
		scanf("%d %d %d",&a,&b,&valor);//Lê destino, origem e tempo da viagem
		InserirAresta(&gTempo,a,b,valor);//Armazena no grafo tempo
		scanf("%d",&valor);//Lê preço da viagem
		InserirAresta(&gPreco,a,b,valor);//Armazena no grafo preço
	}

	scanf("%d %d",&a,&b);//Lê a origem e o destino
	int caminho[gTempo.nVertices];//Cria o vetor de caminhos
	dijkstra(gTempo,a,caminho);//Executa o algoritmo de Dijkstra
	
	int totalPreco=0;//Armazena o preço total
	int totalTempo=0;//Armazena o tempo total
	
	ListaMedia caminhoLista;//Lista usada para como pilha para armazenar o caminho percorrido
	CriarListaMedia(&caminhoLista);//Inicia a lista
	InserirFinalListaMedia(&caminhoLista,b,1);//Insere o destino na lista
	
	for(int i=b;caminho[i]!=-1;i=caminho[i]){//Percorre o caminho de trás para frente
		//Insere na pilha o vértice usado para chegar em i
		InserirInicioListaMedia(&caminhoLista,caminho[i],1);//Endereço da pilha, valor a ser inserido, peso da nó(usado para determinar peso da aresta, não é usado na pilha)
		ObterValorAresta(&gPreco,caminho[i],i,&valor);//Obtém preço da viagem de caminho[i] até i
		totalPreco+=valor;//Soma o preço da viagem no preço total

		ObterValorAresta(&gTempo,caminho[i],i,&valor);//Obtém tempo da viagem de caminho[i] até i
		totalTempo+=valor;//Soma o tempo da viagem no tempo total
	}
	MostrarListaMedia(&caminhoLista);//Exibe a pilha
	printf("%d %d\n",totalTempo,totalPreco);//Exibe o preço e tempo total
	
	//Libera a memória usada pelas estruturas
	DeletarGrafo(&gTempo);
	DeletarGrafo(&gPreco);
	DestruirListaMedia(&caminhoLista);
	return 0;
}

