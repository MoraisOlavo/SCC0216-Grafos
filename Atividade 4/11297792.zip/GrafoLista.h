//Olavo Morais Borges Pereira 11297792
#ifndef GrafoLista_h
#define GrafoLista_h
#include "ListaMedia.h"
typedef struct{
	int nVertices;//Armazena o numero de vertices
	ListaMedia* vetorListas;//Ponteiro para o vetor de lista
}GrafoLista;

int CriarGrafo(GrafoLista* g,int n);//Cria o grafo com espaco para n vertices
int InserirAresta(GrafoLista* g,int u,int v,int valorAresta);//Insere aresta entre os vertices u,v
int ObterValorAresta(GrafoLista* g,int u,int v,int* valorAresta);
int RemoverAresta(GrafoLista* g,int u,int v);//Remove aresta entre os vertices u,v
void ExibirGrafo(GrafoLista* g);//Exibe na tela o grafo
int DeletarGrafo(GrafoLista* g);//Libera o espaco alocado pelo grafo
#endif
