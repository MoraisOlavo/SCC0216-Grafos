#ifndef ListaMedia_h
#define ListaMedia_h

typedef int elem;

typedef struct No{
	int info;
	int valorAresta;
	int precoPassagem;
	struct No* prox;
}No;

typedef struct{
	No* ini;
	No* fim;
	int numDeNos;
}ListaMedia;

//Cria uma Lista Média
void CriarListaMedia(ListaMedia* l);

//Cria um nó com o valor passado
No* CriarNo(elem info,int valorAresta);//Retorna o endereço do nó criado

//Verifica quantos elementos a lista possui
int NumeroDeElementosListaMedia(ListaMedia* l);//Retorna o número de elementos que a lista possui

//Insere o valor passado no inicio da lista
No* InserirInicioListaMedia(ListaMedia* l,elem valor,int valorAresta);//Retorna o endereço do nó criado

//Insere o valor passado no final da lista
No* InserirFinalListaMedia(ListaMedia* l,elem valor,int valorAresta);//Retorna o endereço do nó criado

//Insere o valor passado na posição passada
No* InserirListaMedia(ListaMedia* l,elem valor,int pos,int valorAresta);//Retorna o endereço do nó criado

//Mostra a lista na tela
void MostrarListaMedia(ListaMedia* l);

//Verifica se um valor está na lista
No** EstaNaListaMedia(ListaMedia* l,elem valor);//Retorna o endereço de quem tem o endereço do nó procurado

//Remove o primeiro elemento da lista
int RemoverInicioListaMedia(ListaMedia* l,elem* retorno);//Retorna se a remoção foi bem sucedida(1) ou se a lista estava vazia(0)

//Remove o último elemento da lista
int RemoverFinalListaMedia(ListaMedia* l,elem* retorno);//Retorna se a remoção foi bem sucedida(1) ou se a lista estava vazia(0)

//Remove o nó com o valor passado da lista
int RemoverValorListaMedia(ListaMedia* l,elem valor);//Retorna se a remoção foi bem sucedida(1) ou se a lista estava vazia ou o elemento procurado não foi encontrado(0)

//Remove o nó na posição passada(ou o último nó caso a posição seja maior que o tamanho da lista
int RemoverPosicaoListaMedia(ListaMedia* l,int pos,elem* retorno);//Retorna se a remoção foi bem sucedida(1) ou se a lista estava vazia(0)

//Verifica se a lista está vazia
int EstaVaziaListaMedia(ListaMedia* l);//Retorna 1 se a lista estiver vazia,0 caso contrário

//Destroi a Lista
void DestruirListaMedia(ListaMedia* l);
#endif
